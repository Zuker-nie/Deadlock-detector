/**
 *  scheduler.h
 *
 *  Full Name: Zuker Nie Chen
 *  Course section: M
 *  Description of the program: FIFO And Banker's Algorithm to simulate a run-time of processes
 *  
 */

// length of a time quantum
#define QUANTUM 2
